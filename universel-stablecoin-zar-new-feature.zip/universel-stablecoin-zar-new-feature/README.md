

- Vite
- React.js
- Tailwind CSS


**Installation**

Install the project dependencies using npm:

```bash
npm install
```

**Running the Project**

```bash
npm run dev
```



#
# universelsta
# universel-stablecoin-zar
